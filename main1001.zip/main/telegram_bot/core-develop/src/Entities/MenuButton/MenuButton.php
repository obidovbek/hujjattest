<?php

namespace Longman\TelegramBot\Entities\MenuButton;

use Longman\TelegramBot\Entities\Entity;

/**
 * @method string getType() Type of the button
 *
 * @method $this setType($type) Type of the button
 */
abstract class MenuButton extends Entity
{

}

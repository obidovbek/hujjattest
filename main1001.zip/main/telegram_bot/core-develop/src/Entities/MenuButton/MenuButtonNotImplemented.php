<?php

namespace Longman\TelegramBot\Entities\MenuButton;

class MenuButtonNotImplemented extends MenuButton
{

}

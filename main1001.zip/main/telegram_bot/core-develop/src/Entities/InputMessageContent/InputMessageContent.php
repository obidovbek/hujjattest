<?php

namespace Longman\TelegramBot\Entities\InputMessageContent;

interface InputMessageContent
{

}

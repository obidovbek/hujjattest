<?php

namespace Longman\TelegramBot\Entities\BotCommandScope;

interface BotCommandScope
{

}

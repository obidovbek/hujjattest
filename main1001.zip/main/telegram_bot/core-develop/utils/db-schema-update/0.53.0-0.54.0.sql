ALTER TABLE `message` ADD COLUMN `game` TEXT NULL COMMENT 'Message is a game, information about the game.' AFTER `document`;
